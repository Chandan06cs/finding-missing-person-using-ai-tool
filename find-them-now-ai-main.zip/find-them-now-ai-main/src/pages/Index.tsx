
import React from "react";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import SearchBar from "@/components/SearchBar";
import ReportForm from "@/components/ReportForm";
import PersonCard from "@/components/PersonCard";
import AIFeatures from "@/components/AIFeatures";
import Map from "@/components/Map";
import Footer from "@/components/Footer";
import { MissingPersonProvider, useMissingPersons } from "@/context/MissingPersonContext";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const MissingPersonsSection = () => {
  const { missingPersons, searchResults, clearSearch } = useMissingPersons();
  const { toast } = useToast();
  
  const displayedPersons = searchResults || missingPersons;
  
  const handleViewAll = () => {
    clearSearch();
    toast({
      title: "All Cases",
      description: "Showing all missing person cases",
    });
  };

  const handleLoadMore = () => {
    toast({
      title: "Feature Coming Soon",
      description: "We're working on adding more cases to our database",
    });
  };

  const handleCardClick = (personId: string) => {
    toast({
      title: "Case Selected",
      description: "Full case details view coming soon",
    });
  };

  return (
    <section id="missing-persons" className="section-padding container px-4 md:px-6">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Missing Persons</h2>
          <p className="text-muted-foreground">
            {searchResults 
              ? `Search Results (${searchResults.length} found)`
              : "Recent cases that need your attention"}
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button variant="outline" onClick={handleViewAll}>View All Cases</Button>
        </div>
      </div>

      {displayedPersons.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {displayedPersons.map((person) => (
            <PersonCard 
              key={person.id} 
              person={person} 
              onClick={() => handleCardClick(person.id)}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <p className="text-xl text-muted-foreground mb-4">No missing person cases match your search criteria</p>
          <Button onClick={clearSearch}>Clear Search</Button>
        </div>
      )}

      <div className="mt-10 text-center">
        <p className="text-muted-foreground mb-4">Can't find who you're looking for?</p>
        <Button onClick={handleLoadMore}>Load More Cases</Button>
      </div>
    </section>
  );
};

const Index = () => {
  return (
    <MissingPersonProvider>
      <div className="flex flex-col min-h-screen">
        <Header />
        <main>
          <Hero />
          <SearchBar />
          <MissingPersonsSection />
          <ReportForm />
          <AIFeatures />
          <Map />
        </main>
        <Footer />
      </div>
    </MissingPersonProvider>
  );
};

export default Index;
