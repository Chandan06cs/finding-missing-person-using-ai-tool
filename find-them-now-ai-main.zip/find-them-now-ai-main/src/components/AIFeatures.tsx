
import React from "react";
import { 
  Scan, 
  MapPin, 
  LineChart, 
  MessageSquare, 
  Video, 
  Fingerprint, 
  Database,
  GanttChartSquare 
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";

const AIFeatures = () => {
  const features = [
    {
      icon: <Scan />,
      title: "Facial Recognition",
      description: "Advanced CNN-based facial recognition that can match missing persons from images and video footage with high accuracy.",
      color: "bg-blue-100 text-blue-700"
    },
    {
      icon: <LineChart />,
      title: "Predictive Analysis",
      description: "Behavioral pattern analysis that can predict potential locations and movement patterns of missing individuals.",
      color: "bg-purple-100 text-purple-700"
    },
    {
      icon: <MapPin />,
      title: "Geospatial Analysis",
      description: "Location-based intelligence that analyzes geographical data to identify high-probability areas for investigation.",
      color: "bg-green-100 text-green-700"
    },
    {
      icon: <MessageSquare />,
      title: "NLP & Social Media",
      description: "Natural language processing algorithms that scan social media and online content for relevant information.",
      color: "bg-amber-100 text-amber-700"
    },
    {
      icon: <Video />,
      title: "Video Analytics",
      description: "Real-time video processing that can identify missing persons in surveillance footage and public camera networks.",
      color: "bg-red-100 text-red-700"
    },
    {
      icon: <Fingerprint />,
      title: "Biometric Matching",
      description: "Multi-factor biometric identification beyond facial features, including gait analysis and other unique identifiers.",
      color: "bg-indigo-100 text-indigo-700"
    },
    {
      icon: <Database />,
      title: "Cross-Database Correlation",
      description: "Integration with multiple databases to cross-reference information and identify connections across different sources.",
      color: "bg-teal-100 text-teal-700"
    },
    {
      icon: <GanttChartSquare />,
      title: "Time-Series Analysis",
      description: "Temporal pattern recognition that can establish timelines and predict future locations based on historical data.",
      color: "bg-cyan-100 text-cyan-700"
    }
  ];

  return (
    <section id="ai-features" className="section-padding container px-4 md:px-6 bg-muted/30">
      <div className="text-center space-y-2 mb-12">
        <h2 className="text-3xl font-bold tracking-tight">AI Technologies</h2>
        <p className="text-muted-foreground max-w-3xl mx-auto">
          Our platform leverages state-of-the-art artificial intelligence technologies to locate missing persons more efficiently than traditional methods.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((feature, index) => (
          <Card key={index} className="card-hover">
            <CardHeader className="pb-2">
              <div className={`w-12 h-12 rounded-lg ${feature.color} flex items-center justify-center mb-2`}>
                {feature.icon}
              </div>
              <CardTitle className="text-xl">{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-foreground/80">
                {feature.description}
              </CardDescription>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-16 bg-gradient-to-r from-primary/10 via-secondary/10 to-primary/10 rounded-xl p-8">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h3 className="text-2xl font-bold mb-4">How Our AI Works Together</h3>
            <p className="mb-6 text-muted-foreground">
              Our system uses a multi-layered approach that combines different AI technologies to maximize the chances of finding missing persons:
            </p>
            <ol className="space-y-3">
              <li className="flex items-start">
                <div className="bg-primary/20 rounded-full text-primary w-6 h-6 flex items-center justify-center shrink-0 mr-3">1</div>
                <p>Images are processed through facial recognition to create a unique biometric profile</p>
              </li>
              <li className="flex items-start">
                <div className="bg-primary/20 rounded-full text-primary w-6 h-6 flex items-center justify-center shrink-0 mr-3">2</div>
                <p>Location data is analyzed to establish patterns and predict possible movements</p>
              </li>
              <li className="flex items-start">
                <div className="bg-primary/20 rounded-full text-primary w-6 h-6 flex items-center justify-center shrink-0 mr-3">3</div>
                <p>Social media and news feeds are continuously scanned for mentions or images</p>
              </li>
              <li className="flex items-start">
                <div className="bg-primary/20 rounded-full text-primary w-6 h-6 flex items-center justify-center shrink-0 mr-3">4</div>
                <p>Public camera networks are monitored in real-time for potential matches</p>
              </li>
              <li className="flex items-start">
                <div className="bg-primary/20 rounded-full text-primary w-6 h-6 flex items-center justify-center shrink-0 mr-3">5</div>
                <p>AI continuously learns and improves its accuracy through each search</p>
              </li>
            </ol>
          </div>

          <div className="bg-card rounded-xl shadow-md p-6 border">
            <div className="space-y-4">
              <h4 className="font-medium">AI Performance Metrics</h4>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Facial Recognition Accuracy</span>
                    <span className="font-medium">96%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: "96%" }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Location Prediction</span>
                    <span className="font-medium">87%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-green-500 rounded-full" style={{ width: "87%" }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Social Media Analysis</span>
                    <span className="font-medium">92%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-amber-500 rounded-full" style={{ width: "92%" }}></div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Average Response Time</span>
                    <span className="font-medium">3.2 hours</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full bg-indigo-500 rounded-full" style={{ width: "85%" }}></div>
                  </div>
                </div>

                <div className="pt-3 text-xs text-muted-foreground">
                  * Based on historical data from 5,000+ cases
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIFeatures;
