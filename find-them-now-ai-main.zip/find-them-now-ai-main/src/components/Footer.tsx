
import React from "react";
import { MapPin, Mail, Phone, Shield, ExternalLink } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-card border-t">
      <div className="container px-4 md:px-6 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="rounded-full bg-primary p-1">
                <MapPin className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="font-bold text-xl">FindThem</span>
            </div>
            <p className="text-muted-foreground">
              Using cutting-edge AI technology to help locate missing persons and reunite families around the world.
            </p>
            <div className="flex space-x-4">
              {["twitter", "facebook", "instagram", "linkedin"].map(social => (
                <a 
                  key={social} 
                  href={`#${social}`} 
                  aria-label={`Visit our ${social} page`}
                  className="h-8 w-8 bg-muted rounded-full flex items-center justify-center hover:bg-accent transition-colors"
                >
                  <span className="sr-only">{social}</span>
                  <div className="h-4 w-4 bg-foreground/70 mask-icon" style={{ maskImage: `url(/icons/${social}.svg)` }}></div>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-medium text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#about" className="text-muted-foreground hover:text-primary transition-colors">About Us</a></li>
              <li><a href="#report" className="text-muted-foreground hover:text-primary transition-colors">Report Missing Person</a></li>
              <li><a href="#search" className="text-muted-foreground hover:text-primary transition-colors">Search Database</a></li>
              <li><a href="#ai-features" className="text-muted-foreground hover:text-primary transition-colors">AI Technology</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Success Stories</a></li>
              <li><a href="#" className="text-muted-foreground hover:text-primary transition-colors">Volunteer</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-medium text-lg mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors flex items-center">
                  <ExternalLink className="h-3.5 w-3.5 mr-1.5" /> Missing Person Laws
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors flex items-center">
                  <ExternalLink className="h-3.5 w-3.5 mr-1.5" /> Safety Tips
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors flex items-center">
                  <ExternalLink className="h-3.5 w-3.5 mr-1.5" /> Support Groups
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors flex items-center">
                  <ExternalLink className="h-3.5 w-3.5 mr-1.5" /> Law Enforcement Portal
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors flex items-center">
                  <ExternalLink className="h-3.5 w-3.5 mr-1.5" /> API Documentation
                </a>
              </li>
              <li>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors flex items-center">
                  <Shield className="h-3.5 w-3.5 mr-1.5" /> Privacy Policy
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-medium text-lg mb-4">Contact Us</h3>
            <div className="space-y-3">
              <div className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 text-muted-foreground shrink-0 mt-0.5" />
                <p className="text-muted-foreground">
                  123 AI Innovation Center<br />
                  Tech Park, San Francisco<br />
                  CA 94107, USA
                </p>
              </div>
              <div className="flex items-center">
                <Phone className="h-5 w-5 mr-2 text-muted-foreground" />
                <a href="tel:+1-800-123-4567" className="text-muted-foreground hover:text-primary transition-colors">
                  +1 (800) 123-4567
                </a>
              </div>
              <div className="flex items-center">
                <Mail className="h-5 w-5 mr-2 text-muted-foreground" />
                <a href="mailto:contact@findthem-ai.org" className="text-muted-foreground hover:text-primary transition-colors">
                  contact@findthem-ai.org
                </a>
              </div>
              <div className="pt-3">
                <button className="bg-primary/10 text-primary hover:bg-primary/20 px-4 py-2 rounded-md text-sm transition-colors inline-flex items-center">
                  <Phone className="h-4 w-4 mr-2" /> Emergency Hotline
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} FindThem AI. All rights reserved.
          </p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground">Terms of Service</a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground">Privacy Policy</a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
