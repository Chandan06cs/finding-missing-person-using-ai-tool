
import React, { useState } from "react";
import { Menu, X, Search, User, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-background/80 backdrop-blur-md border-b">
      <div className="container flex items-center justify-between h-16 px-4 md:px-6">
        <div className="flex items-center">
          <a href="/" className="flex items-center space-x-2">
            <div className="rounded-full bg-primary p-1">
              <MapPin className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="font-bold text-xl md:text-2xl">FindThem</span>
          </a>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <a href="#about" className="text-sm font-medium hover:text-primary transition-colors">
            About
          </a>
          <a href="#report" className="text-sm font-medium hover:text-primary transition-colors">
            Report
          </a>
          <a href="#search" className="text-sm font-medium hover:text-primary transition-colors">
            Search
          </a>
          <a href="#ai-features" className="text-sm font-medium hover:text-primary transition-colors">
            AI Features
          </a>
          <a href="#map" className="text-sm font-medium hover:text-primary transition-colors">
            Map
          </a>
        </nav>

        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" className="hidden md:flex">
            <Search className="h-5 w-5" />
          </Button>
          <Button variant="outline" className="hidden md:flex">
            <User className="mr-2 h-5 w-5" /> Login
          </Button>
          <Button variant="outline" className="md:hidden" onClick={toggleMenu}>
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobile && isMenuOpen && (
        <div className="fixed inset-0 top-16 z-40 bg-background border-t animate-fade-in">
          <nav className="container flex flex-col space-y-4 p-6">
            <a href="#about" className="text-lg font-medium py-2 hover:text-primary transition-colors" onClick={toggleMenu}>
              About
            </a>
            <a href="#report" className="text-lg font-medium py-2 hover:text-primary transition-colors" onClick={toggleMenu}>
              Report
            </a>
            <a href="#search" className="text-lg font-medium py-2 hover:text-primary transition-colors" onClick={toggleMenu}>
              Search
            </a>
            <a href="#ai-features" className="text-lg font-medium py-2 hover:text-primary transition-colors" onClick={toggleMenu}>
              AI Features
            </a>
            <a href="#map" className="text-lg font-medium py-2 hover:text-primary transition-colors" onClick={toggleMenu}>
              Map
            </a>
            <div className="pt-4 border-t">
              <Button className="w-full mb-4" variant="default">
                <Search className="mr-2 h-5 w-5" /> Search
              </Button>
              <Button className="w-full" variant="outline">
                <User className="mr-2 h-5 w-5" /> Login
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
