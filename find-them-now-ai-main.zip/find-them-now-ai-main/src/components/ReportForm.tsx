
import React, { useState } from "react";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useMissingPersons, MissingPerson } from "@/context/MissingPersonContext";
import { Upload, Camera, Info, MapPin } from "lucide-react";

const ReportForm = () => {
  const { toast } = useToast();
  const { addMissingPerson } = useMissingPersons();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "",
    lastSeen: "",
    description: "",
    image: "",
    imagePreview: "",
    reportedBy: "",
    contactInfo: "",
    height: "",
    weight: "",
    hairColor: "",
    eyeColor: "",
    distinguishingFeatures: "",
    lastSeenWearing: "",
    lastSeenLocation: ""
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({
          ...prev,
          image: file.name, // In a real app, we would upload the file to a server
          imagePreview: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const nextStep = () => {
    setStep(step + 1);
  };

  const prevStep = () => {
    setStep(step - 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, we'd validate the form and handle the image upload properly
    const currentDate = new Date().toISOString().split('T')[0];
    const newPerson: MissingPerson = {
      id: crypto.randomUUID(),
      name: formData.name,
      age: parseInt(formData.age) || 0,
      gender: formData.gender,
      lastSeen: formData.lastSeen,
      description: formData.description,
      image: formData.imagePreview || "https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=400", // Fallback image
      reportedBy: formData.reportedBy,
      contactInfo: formData.contactInfo,
      locations: [{ 
        lat: 0, // In a real app, we would geocode the address
        lng: 0,
        address: formData.lastSeenLocation
      }],
      status: "investigating",
      dateReported: currentDate,
      height: formData.height,
      weight: formData.weight,
      hairColor: formData.hairColor,
      eyeColor: formData.eyeColor,
      distinguishingFeatures: formData.distinguishingFeatures,
      lastSeenWearing: formData.lastSeenWearing
    };

    addMissingPerson(newPerson);
    toast({
      title: "Report Submitted",
      description: "Your missing person report has been submitted successfully.",
    });

    // Reset form
    setFormData({
      name: "",
      age: "",
      gender: "",
      lastSeen: "",
      description: "",
      image: "",
      imagePreview: "",
      reportedBy: "",
      contactInfo: "",
      height: "",
      weight: "",
      hairColor: "",
      eyeColor: "",
      distinguishingFeatures: "",
      lastSeenWearing: "",
      lastSeenLocation: ""
    });
    setStep(1);
  };

  return (
    <section id="report" className="section-padding container px-4 md:px-6">
      <div className="grid md:grid-cols-2 gap-10 items-center">
        <div className="space-y-4">
          <div className="inline-flex items-center rounded-lg bg-muted px-3 py-1 text-sm">
            <Info className="mr-1 h-4 w-4" />
            Report a Missing Person
          </div>
          <h2 className="text-3xl font-bold tracking-tight">Help Us Find Your Loved Ones</h2>
          <p className="text-muted-foreground">
            Filing a report is the first step to leveraging our AI-powered search capabilities. The more information you provide, the better our systems can help locate the missing person.
          </p>
          
          <div className="bg-accent/10 rounded-lg p-4 space-y-3">
            <h3 className="font-medium">How Our AI Works</h3>
            <p className="text-sm">
              Our advanced AI system processes the information you provide and:
            </p>
            <ul className="text-sm list-disc pl-5 space-y-1">
              <li>Creates a facial recognition profile</li>
              <li>Analyzes surveillance camera footage from public areas</li>
              <li>Scans social media and news articles</li>
              <li>Predicts possible locations based on behavioral patterns</li>
              <li>Alerts authorities and users when potential matches are found</li>
            </ul>
            <p className="text-sm text-muted-foreground">
              Your data is kept secure and is only used for the purpose of locating the missing person.
            </p>
          </div>
        </div>
        
        <div className="bg-card rounded-xl shadow-sm border p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {step === 1 && (
              <div className="space-y-4 animate-fade-in">
                <h3 className="text-xl font-medium text-center">Personal Information</h3>
                
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter full name of missing person"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="age">Age</Label>
                    <Input
                      id="age"
                      name="age"
                      type="number"
                      value={formData.age}
                      onChange={handleChange}
                      placeholder="Age"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="gender">Gender</Label>
                    <select
                      id="gender"
                      name="gender"
                      value={formData.gender}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    >
                      <option value="">Select gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="image">Upload Photo</Label>
                  <div className="border-2 border-dashed rounded-lg p-4 text-center">
                    {formData.imagePreview ? (
                      <div className="relative w-32 h-32 mx-auto">
                        <img
                          src={formData.imagePreview}
                          alt="Preview"
                          className="w-full h-full object-cover rounded-lg"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="absolute top-0 right-0 -mt-2 -mr-2 h-6 w-6 rounded-full p-0"
                          onClick={() => setFormData(prev => ({ ...prev, image: "", imagePreview: "" }))}
                        >
                          ×
                        </Button>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center space-y-2">
                        <div className="bg-secondary/30 rounded-full p-3">
                          <Camera className="h-6 w-6 text-muted-foreground" />
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Drag & drop or click to upload
                        </div>
                        <Input
                          id="image"
                          name="image"
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                        <Button type="button" variant="outline" onClick={() => document.getElementById("image")?.click()}>
                          <Upload className="mr-2 h-4 w-4" /> Upload Photo
                        </Button>
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Please upload a clear, recent photo. Our AI uses facial recognition to identify matches.
                  </p>
                </div>
                
                <Button type="button" onClick={nextStep} className="w-full">
                  Continue
                </Button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4 animate-fade-in">
                <h3 className="text-xl font-medium text-center">Physical Description</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="height">Height</Label>
                    <Input
                      id="height"
                      name="height"
                      value={formData.height}
                      onChange={handleChange}
                      placeholder="e.g., 5'10&quot;"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="weight">Weight</Label>
                    <Input
                      id="weight"
                      name="weight"
                      value={formData.weight}
                      onChange={handleChange}
                      placeholder="e.g., 160 lbs"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="hairColor">Hair Color</Label>
                    <Input
                      id="hairColor"
                      name="hairColor"
                      value={formData.hairColor}
                      onChange={handleChange}
                      placeholder="Hair color"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="eyeColor">Eye Color</Label>
                    <Input
                      id="eyeColor"
                      name="eyeColor"
                      value={formData.eyeColor}
                      onChange={handleChange}
                      placeholder="Eye color"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="distinguishingFeatures">Distinguishing Features</Label>
                  <Textarea
                    id="distinguishingFeatures"
                    name="distinguishingFeatures"
                    value={formData.distinguishingFeatures}
                    onChange={handleChange}
                    placeholder="Scars, tattoos, birthmarks, etc."
                    rows={2}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="lastSeenWearing">Last Seen Wearing</Label>
                  <Textarea
                    id="lastSeenWearing"
                    name="lastSeenWearing"
                    value={formData.lastSeenWearing}
                    onChange={handleChange}
                    placeholder="Describe clothing and accessories"
                    rows={2}
                  />
                </div>
                
                <div className="flex gap-4">
                  <Button type="button" variant="outline" onClick={prevStep} className="w-1/2">
                    Back
                  </Button>
                  <Button type="button" onClick={nextStep} className="w-1/2">
                    Continue
                  </Button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4 animate-fade-in">
                <h3 className="text-xl font-medium text-center">Last Seen Information</h3>
                
                <div className="space-y-2">
                  <Label htmlFor="lastSeen">Last Seen Date</Label>
                  <Input
                    id="lastSeen"
                    name="lastSeen"
                    type="date"
                    value={formData.lastSeen}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="lastSeenLocation" className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" /> Last Seen Location
                  </Label>
                  <Input
                    id="lastSeenLocation"
                    name="lastSeenLocation"
                    value={formData.lastSeenLocation}
                    onChange={handleChange}
                    placeholder="Address or location description"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Circumstances</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Describe the circumstances of disappearance"
                    rows={3}
                    required
                  />
                </div>
                
                <hr />
                
                <div className="space-y-2">
                  <Label htmlFor="reportedBy">Your Name</Label>
                  <Input
                    id="reportedBy"
                    name="reportedBy"
                    value={formData.reportedBy}
                    onChange={handleChange}
                    placeholder="Your full name"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="contactInfo">Your Contact Information</Label>
                  <Input
                    id="contactInfo"
                    name="contactInfo"
                    value={formData.contactInfo}
                    onChange={handleChange}
                    placeholder="Phone number or email address"
                    required
                  />
                </div>
                
                <div className="flex gap-4">
                  <Button type="button" variant="outline" onClick={prevStep} className="w-1/2">
                    Back
                  </Button>
                  <Button type="submit" className="w-1/2">
                    Submit Report
                  </Button>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </section>
  );
};

export default ReportForm;
