
import React from "react";
import { MapPin, Calendar, AlertCircle, CheckCircle, Clock, User, Phone } from "lucide-react";
import { MissingPerson } from "@/context/MissingPersonContext";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AspectRatio } from "@/components/ui/aspect-ratio";

interface PersonCardProps {
  person: MissingPerson;
  onClick?: () => void;
}

const PersonCard: React.FC<PersonCardProps> = ({ person, onClick }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "missing":
        return "text-destructive bg-destructive/10 border-destructive/20";
      case "found":
        return "text-green-700 bg-green-100 border-green-200";
      case "investigating":
        return "text-amber-700 bg-amber-100 border-amber-200";
      default:
        return "text-muted-foreground";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "missing":
        return <AlertCircle className="h-3.5 w-3.5 mr-1" />;
      case "found":
        return <CheckCircle className="h-3.5 w-3.5 mr-1" />;
      case "investigating":
        return <Clock className="h-3.5 w-3.5 mr-1" />;
      default:
        return null;
    }
  };

  // Calculate days since last seen
  const lastSeenDate = new Date(person.lastSeen);
  const currentDate = new Date();
  const diffTime = Math.abs(currentDate.getTime() - lastSeenDate.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  const handleContactClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (person.contactInfo?.startsWith('+91')) {
      window.open(`tel:${person.contactInfo.replace(/\s/g, '')}`);
    } else {
      window.open(`mailto:${person.contactInfo}`);
    }
  };

  const handleLocationClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (person.locations && person.locations[0]) {
      const { lat, lng } = person.locations[0];
      window.open(`https://maps.google.com/?q=${lat},${lng}`);
    }
  };

  return (
    <Card 
      className={`overflow-hidden hover:shadow-md transition-all duration-200 cursor-pointer ${person.status === "found" ? "opacity-70" : ""}`}
      onClick={onClick}
    >
      <div className="relative">
        <AspectRatio ratio={4/3}>
          <img 
            src={person.image} 
            alt={person.name} 
            className={`w-full h-full object-cover ${person.status === "found" ? "grayscale" : ""}`}
            loading="lazy"
          />
        </AspectRatio>
        <Badge 
          className={`absolute top-2 right-2 ${getStatusColor(person.status)} flex items-center`}
        >
          {getStatusIcon(person.status)}
          {person.status.charAt(0).toUpperCase() + person.status.slice(1)}
        </Badge>
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="text-xl">{person.name}</CardTitle>
        <CardDescription className="flex items-center space-x-1">
          <div className="flex items-center">
            <Calendar className="h-3.5 w-3.5 mr-1 text-muted-foreground" />
            <span>Age: {person.age}</span>
          </div>
          <span>•</span>
          <span>{person.gender}</span>
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2 pb-3">
        <div className="flex items-start space-x-2">
          <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground shrink-0" />
          <p 
            className="text-sm text-muted-foreground hover:text-primary hover:underline"
            onClick={handleLocationClick}
          >
            {person.locations && person.locations[0]?.address || "Location unknown"}
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Missing for {diffDays} days</p>
        </div>
        <div className="flex items-start space-x-2">
          <User className="h-4 w-4 mt-0.5 text-muted-foreground shrink-0" />
          <p className="text-sm">{person.reportedBy || "Unknown reporter"}</p>
        </div>
        <div className="flex items-start space-x-2">
          <Phone className="h-4 w-4 mt-0.5 text-muted-foreground shrink-0" />
          <p 
            className="text-sm hover:text-primary hover:underline"
            onClick={handleContactClick}
          >
            {person.contactInfo || "No contact info"}
          </p>
        </div>
        {person.lastSeenWearing && (
          <p className="text-sm line-clamp-2">
            <span className="font-medium">Last seen wearing:</span> {person.lastSeenWearing}
          </p>
        )}
      </CardContent>
      <CardFooter className="border-t pt-3 pb-3 flex gap-2">
        <Button variant="secondary" className="w-1/2" size="sm" onClick={onClick}>
          View Details
        </Button>
        <Button variant="outline" className="w-1/2" size="sm" onClick={handleContactClick}>
          Contact
        </Button>
      </CardFooter>
    </Card>
  );
};

export default PersonCard;
