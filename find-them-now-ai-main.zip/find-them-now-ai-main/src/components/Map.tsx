
import React, { useState, useEffect } from 'react';
import { useMissingPersons, MissingPerson } from '@/context/MissingPersonContext';
import { MapPin, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';

const Map = () => {
  const { missingPersons } = useMissingPersons();
  const [mapUrl, setMapUrl] = useState('');
  const [selectedPerson, setSelectedPerson] = useState<MissingPerson | null>(null);
  const [mapLoadError, setMapLoadError] = useState(false);
  const [activeTab, setActiveTab] = useState('heatmap');

  useEffect(() => {
    // In a real app, we would use a proper map library like Mapbox or Google Maps
    // For this demo, we'll use a static map image with pins
    
    // This URL would normally be constructed with API keys and markers
    // Since we don't have real APIs integrated, we'll use a placeholder
    const generateMapUrl = () => {
      try {
        // In a real implementation, this would be a call to a map service API
        // For now, we'll just use a static image
        return 'https://images.unsplash.com/photo-1524661135-423995f22d0b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80';
      } catch (err) {
        console.error('Error generating map URL:', err);
        setMapLoadError(true);
        return '';
      }
    };

    setMapUrl(generateMapUrl());
  }, [missingPersons]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "missing": return "text-red-600";
      case "found": return "text-green-600";
      case "investigating": return "text-amber-600";
      default: return "text-gray-600";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "missing": return <AlertCircle className="h-4 w-4" />;
      case "found": return <CheckCircle className="h-4 w-4" />;
      case "investigating": return <Clock className="h-4 w-4" />;
      default: return <MapPin className="h-4 w-4" />;
    }
  };

  return (
    <section id="map" className="section-padding container px-4 md:px-6">
      <div className="text-center space-y-2 mb-8">
        <h2 className="text-3xl font-bold tracking-tight">Geospatial Analysis</h2>
        <p className="text-muted-foreground max-w-3xl mx-auto">
          Our AI-powered geospatial analysis helps identify patterns and predict potential locations of missing persons based on reported sightings and historical data.
        </p>
      </div>

      <div className="bg-card rounded-xl border shadow-sm overflow-hidden">
        <Tabs defaultValue="heatmap" className="w-full" onValueChange={setActiveTab}>
          <div className="border-b px-4">
            <TabsList className="h-12">
              <TabsTrigger value="heatmap" className="data-[state=active]:bg-background">Heatmap</TabsTrigger>
              <TabsTrigger value="timeline" className="data-[state=active]:bg-background">Timeline</TabsTrigger>
              <TabsTrigger value="clusters" className="data-[state=active]:bg-background">Clusters</TabsTrigger>
            </TabsList>
          </div>

          <div className="relative">
            {mapLoadError ? (
              <div className="flex items-center justify-center h-[400px] bg-muted/30">
                <div className="text-center p-4">
                  <AlertCircle className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
                  <h3 className="font-medium text-lg">Map Failed to Load</h3>
                  <p className="text-muted-foreground">Please try again later or check your connection.</p>
                </div>
              </div>
            ) : (
              <div className="relative h-[400px] md:h-[500px]">
                <img 
                  src={mapUrl} 
                  alt="Map visualization" 
                  className="w-full h-full object-cover"
                />
                
                {/* Map overlay with simulated data points */}
                <div className="absolute inset-0 pointer-events-none">
                  {activeTab === 'heatmap' && (
                    <>
                      <div className="absolute top-1/3 left-1/4 w-32 h-32 rounded-full bg-red-500/20 animate-pulse-slow"></div>
                      <div className="absolute top-1/2 left-1/3 w-24 h-24 rounded-full bg-red-500/30 animate-pulse-slow"></div>
                      <div className="absolute bottom-1/3 right-1/3 w-40 h-40 rounded-full bg-red-500/20 animate-pulse-slow"></div>
                    </>
                  )}

                  {activeTab === 'clusters' && (
                    <>
                      {/* Simulated clusters */}
                      <div className="absolute top-1/4 left-1/4">
                        <div className="relative">
                          <div className="absolute -top-3 -left-3 w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white text-xs">
                            5
                          </div>
                          <MapPin className="h-6 w-6 text-primary" />
                        </div>
                      </div>
                      <div className="absolute bottom-1/3 right-1/4">
                        <div className="relative">
                          <div className="absolute -top-3 -left-3 w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white text-xs">
                            3
                          </div>
                          <MapPin className="h-6 w-6 text-primary" />
                        </div>
                      </div>
                      <div className="absolute top-1/2 right-1/3">
                        <div className="relative">
                          <div className="absolute -top-3 -left-3 w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white text-xs">
                            2
                          </div>
                          <MapPin className="h-6 w-6 text-primary" />
                        </div>
                      </div>
                    </>
                  )}

                  {activeTab === 'timeline' && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="bg-white/90 p-4 rounded-lg max-w-md">
                        <h3 className="font-medium text-lg">Timeline View</h3>
                        <p className="text-sm text-muted-foreground mb-2">Showing movement patterns over time</p>
                        <div className="h-2 bg-gray-200 rounded-full mb-4">
                          <div className="h-full w-1/2 bg-primary rounded-full"></div>
                        </div>
                        <div className="space-y-2">
                          {[1, 2, 3].map((i) => (
                            <div key={i} className="flex items-center space-x-2 text-sm">
                              <div className={`h-3 w-3 rounded-full ${i === 1 ? 'bg-red-500' : i === 2 ? 'bg-amber-500' : 'bg-green-500'}`}></div>
                              <div>{i === 1 ? 'Initial location' : i === 2 ? 'Reported sighting' : 'Predicted location'}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Layer controls */}
                <div className="absolute top-4 right-4">
                  <Card className="w-auto">
                    <CardContent className="p-3">
                      <div className="space-y-2">
                        <div className="text-sm font-medium">Map Layers</div>
                        <div className="space-y-1.5">
                          <div className="flex items-center">
                            <input type="checkbox" id="sightings" className="mr-2" defaultChecked />
                            <label htmlFor="sightings" className="text-xs">Reported Sightings</label>
                          </div>
                          <div className="flex items-center">
                            <input type="checkbox" id="predictions" className="mr-2" defaultChecked />
                            <label htmlFor="predictions" className="text-xs">AI Predictions</label>
                          </div>
                          <div className="flex items-center">
                            <input type="checkbox" id="cctv" className="mr-2" defaultChecked />
                            <label htmlFor="cctv" className="text-xs">CCTV Coverage</label>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 bg-muted/30 border-t">
            <h3 className="text-sm font-medium mb-2">Missing Persons Locations</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
              {missingPersons.map((person) => (
                <div 
                  key={person.id}
                  className={`flex items-center space-x-2 p-2 border rounded-md cursor-pointer transition-colors ${
                    selectedPerson?.id === person.id ? 'bg-background border-primary' : 'bg-card hover:bg-muted/50'
                  }`}
                  onClick={() => setSelectedPerson(person)}
                >
                  <div className="w-8 h-8 rounded-full overflow-hidden bg-muted">
                    <img 
                      src={person.image} 
                      alt={person.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="truncate flex-1">
                    <div className="text-xs font-medium truncate">{person.name}</div>
                    <div className={`flex items-center text-xs ${getStatusColor(person.status)}`}>
                      {getStatusIcon(person.status)}
                      <span className="ml-0.5 truncate">{person.status}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Tabs>
      </div>

      <div className="mt-4 text-sm text-center text-muted-foreground">
        <p>This visualization uses simulated data for demonstration purposes.</p>
        <p>In a production environment, this would integrate with real geospatial data and AI predictions.</p>
      </div>
    </section>
  );
};

export default Map;
