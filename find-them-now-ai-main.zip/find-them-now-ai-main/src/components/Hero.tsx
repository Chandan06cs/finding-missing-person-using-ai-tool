
import React from "react";
import { Button } from "@/components/ui/button";
import { Search, AlertCircle } from "lucide-react";

const Hero = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-primary/10 via-background to-background">
      <div className="container px-4 md:px-6 py-16 md:py-24">
        <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
          <div className="space-y-6">
            <div className="space-y-3">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Finding Missing Persons with <span className="gradient-text">AI Technology</span>
              </h1>
              <p className="text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Our platform leverages advanced artificial intelligence to help locate missing individuals faster and more efficiently than traditional methods.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button size="lg" className="bg-primary">
                <Search className="mr-2 h-5 w-5" /> Search Database
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#report">
                  <AlertCircle className="mr-2 h-5 w-5" /> Report Missing Person
                </a>
              </Button>
            </div>
            <div className="flex items-center space-x-2 text-sm">
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="rounded-full border-2 border-background w-8 h-8 bg-gray-200"
                    style={{
                      backgroundImage: `url(https://source.unsplash.com/random/150x150?face&${i})`,
                      backgroundSize: "cover",
                      backgroundPosition: "center"
                    }}
                  />
                ))}
              </div>
              <div className="text-muted-foreground">
                Helping <span className="font-medium text-foreground">thousands</span> of families reunite
              </div>
            </div>
          </div>

          <div className="mx-auto lg:mx-0 relative max-w-full">
            <div className="p-4 relative z-10">
              <div className="w-full h-full aspect-video rounded-lg bg-gradient-to-br from-primary/40 to-secondary/40 flex items-center justify-center overflow-hidden">
                <div className="grid grid-cols-2 gap-2 p-2 w-full h-full">
                  <div className="relative rounded-md overflow-hidden">
                    <img 
                      src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400" 
                      alt="Missing person search" 
                      className="object-cover w-full h-full"
                    />
                    <div className="absolute inset-0 border-2 border-white/30 rounded-md"></div>
                  </div>
                  <div className="grid grid-rows-2 gap-2">
                    <div className="relative rounded-md overflow-hidden">
                      <img 
                        src="https://images.unsplash.com/photo-1581866327077-6e5e9a8b5787?auto=format&fit=crop&q=80&w=200" 
                        alt="Facial recognition" 
                        className="object-cover w-full h-full"
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-full h-full absolute border-2 border-white/30 rounded-md"></div>
                        <svg className="w-12 h-12 text-white/70" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <circle cx="50" cy="30" r="6" stroke="currentColor" strokeWidth="2" />
                          <circle cx="30" cy="50" r="4" stroke="currentColor" strokeWidth="2" />
                          <circle cx="70" cy="50" r="4" stroke="currentColor" strokeWidth="2" />
                          <path d="M30 50 L50 70 L70 50" stroke="currentColor" strokeWidth="2" fill="none" />
                        </svg>
                      </div>
                    </div>
                    <div className="relative rounded-md overflow-hidden">
                      <img 
                        src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200" 
                        alt="Location tracking" 
                        className="object-cover w-full h-full"
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-full h-full absolute border-2 border-white/30 rounded-md"></div>
                        <div className="absolute top-1 right-1 bg-green-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                          Match
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-background z-0"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
