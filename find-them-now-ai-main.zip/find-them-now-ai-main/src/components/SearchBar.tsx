
import React, { useState } from "react";
import { Search, Filter, MapPin, Clock, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMissingPersons } from "@/context/MissingPersonContext";
import { useToast } from "@/hooks/use-toast";

const SearchBar = () => {
  const [query, setQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [ageRange, setAgeRange] = useState({ min: "", max: "" });
  const [gender, setGender] = useState("");
  const [dateRange, setDateRange] = useState({ from: "", to: "" });
  const [location, setLocation] = useState("");

  const { searchMissingPersons, loading, setSearchResults } = useMissingPersons();
  const { toast } = useToast();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!query && !ageRange.min && !ageRange.max && !gender && !dateRange.from && !dateRange.to && !location) {
      toast({
        title: "Search Error",
        description: "Please enter at least one search criteria",
        variant: "destructive"
      });
      return;
    }
    
    // Perform search using context
    const results = searchMissingPersons(query);
    
    // Filter by additional criteria
    const filteredResults = results.filter(person => {
      let matches = true;
      
      // Filter by age range
      if (ageRange.min && Number(person.age) < Number(ageRange.min)) matches = false;
      if (ageRange.max && Number(person.age) > Number(ageRange.max)) matches = false;
      
      // Filter by gender
      if (gender && person.gender.toLowerCase() !== gender.toLowerCase()) matches = false;
      
      // Filter by date range
      if (dateRange.from) {
        const fromDate = new Date(dateRange.from);
        const lastSeenDate = new Date(person.lastSeen);
        if (lastSeenDate < fromDate) matches = false;
      }
      
      if (dateRange.to) {
        const toDate = new Date(dateRange.to);
        const lastSeenDate = new Date(person.lastSeen);
        if (lastSeenDate > toDate) matches = false;
      }
      
      // Filter by location
      if (location && person.locations) {
        const locationMatches = person.locations.some(loc => 
          loc.address?.toLowerCase().includes(location.toLowerCase())
        );
        if (!locationMatches) matches = false;
      }
      
      return matches;
    });
    
    setSearchResults(filteredResults);
    
    if (filteredResults.length === 0) {
      toast({
        title: "No Matches Found",
        description: "Try broadening your search criteria",
        variant: "default"
      });
    } else {
      toast({
        title: "Search Results",
        description: `Found ${filteredResults.length} match${filteredResults.length === 1 ? '' : 'es'}`,
      });
      
      // Scroll to search results
      document.getElementById("missing-persons")?.scrollIntoView({ behavior: "smooth" });
    }
  };

  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  const clearFilters = () => {
    setAgeRange({ min: "", max: "" });
    setGender("");
    setDateRange({ from: "", to: "" });
    setLocation("");
    setQuery("");
    setSearchResults(null);
    
    toast({
      title: "Filters Cleared",
      description: "All search filters have been reset"
    });
  };

  return (
    <section id="search" className="section-padding container px-4 md:px-6">
      <div className="mx-auto max-w-3xl space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold tracking-tight">Search Database</h2>
          <p className="text-muted-foreground">
            Search our database of missing persons using various criteria
          </p>
        </div>

        <div className="w-full">
          <form onSubmit={handleSearch} className="w-full">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search by name, description, or clothing..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-10 pr-20 py-3 rounded-lg border focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center">
                <button
                  type="button"
                  onClick={toggleFilters}
                  className="mr-2 p-1.5 rounded-md hover:bg-muted transition-colors"
                >
                  <Filter className={`h-5 w-5 ${showFilters ? 'text-primary' : 'text-muted-foreground'}`} />
                </button>
                <Button type="submit" className="rounded-md py-1.5 px-3" disabled={loading}>
                  {loading ? "Searching..." : "Search"}
                </Button>
              </div>
            </div>

            {showFilters && (
              <div className="mt-4 p-4 border rounded-lg bg-card animate-fade-in">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-medium">Advanced Filters</h3>
                  <button 
                    type="button" 
                    onClick={clearFilters}
                    className="text-sm text-muted-foreground hover:text-primary flex items-center"
                  >
                    <X className="h-3.5 w-3.5 mr-1" /> Clear filters
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Age Range</label>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        placeholder="Min"
                        value={ageRange.min}
                        onChange={(e) => setAgeRange({...ageRange, min: e.target.value})}
                        className="w-1/2 px-3 py-2 border rounded-md"
                      />
                      <input
                        type="number"
                        placeholder="Max"
                        value={ageRange.max}
                        onChange={(e) => setAgeRange({...ageRange, max: e.target.value})}
                        className="w-1/2 px-3 py-2 border rounded-md"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Gender</label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value)}
                      className="w-full px-3 py-2 border rounded-md"
                    >
                      <option value="">Any</option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center">
                      <Clock className="h-4 w-4 mr-1" /> Last Seen Date Range
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="date"
                        value={dateRange.from}
                        onChange={(e) => setDateRange({...dateRange, from: e.target.value})}
                        className="w-1/2 px-3 py-2 border rounded-md"
                      />
                      <input
                        type="date"
                        value={dateRange.to}
                        onChange={(e) => setDateRange({...dateRange, to: e.target.value})}
                        className="w-1/2 px-3 py-2 border rounded-md"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium flex items-center">
                      <MapPin className="h-4 w-4 mr-1" /> Location
                    </label>
                    <input
                      type="text"
                      placeholder="City, state, or country"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full px-3 py-2 border rounded-md"
                    />
                  </div>
                </div>
              </div>
            )}
          </form>

          <p className="mt-2 text-xs text-muted-foreground text-center">
            We use facial recognition, geospatial data, and natural language processing to find matches
          </p>
        </div>
      </div>
    </section>
  );
};

export default SearchBar;
