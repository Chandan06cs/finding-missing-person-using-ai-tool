
import React, { createContext, useState, useContext, ReactNode, useEffect } from "react";

export interface Location {
  lat: number;
  lng: number;
  address?: string;
  timestamp?: string;
}

export interface MissingPerson {
  id: string;
  name: string;
  age: number;
  gender: string;
  lastSeen: string;
  description: string;
  image: string;
  reportedBy: string;
  contactInfo: string;
  locations?: Location[];
  status: "missing" | "found" | "investigating";
  dateReported: string;
  height?: string;
  weight?: string;
  hairColor?: string;
  eyeColor?: string;
  distinguishingFeatures?: string;
  lastSeenWearing?: string;
}

interface MissingPersonContextType {
  missingPersons: MissingPerson[];
  addMissingPerson: (person: MissingPerson) => void;
  updateMissingPerson: (id: string, person: Partial<MissingPerson>) => void;
  deleteMissingPerson: (id: string) => void;
  getMissingPerson: (id: string) => MissingPerson | undefined;
  searchMissingPersons: (query: string) => MissingPerson[];
  loading: boolean;
  clearSearch: () => void;
  searchResults: MissingPerson[] | null;
  setSearchResults: React.Dispatch<React.SetStateAction<MissingPerson[] | null>>;
}

const MissingPersonContext = createContext<MissingPersonContextType | undefined>(undefined);

// Sample data with Indian names for demo purposes
const sampleMissingPersons: MissingPerson[] = [
  {
    id: "1",
    name: "Priya Sharma",
    age: 25,
    gender: "Female",
    lastSeen: "2023-05-15",
    description: "Last seen near Connaught Place. She was wearing a blue salwar kameez.",
    image: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&q=80&w=400",
    reportedBy: "Raj Sharma",
    contactInfo: "+91 98765 43210",
    locations: [
      { lat: 28.6304, lng: 77.2177, address: "Connaught Place, New Delhi", timestamp: "2023-05-15T14:30:00" },
      { lat: 28.6258, lng: 77.2209, address: "Janpath, New Delhi", timestamp: "2023-05-15T15:45:00" }
    ],
    status: "missing",
    dateReported: "2023-05-16",
    height: "5'4\"",
    weight: "55 kg",
    hairColor: "Black",
    eyeColor: "Brown",
    distinguishingFeatures: "Small birthmark on left cheek",
    lastSeenWearing: "Blue salwar kameez and silver earrings"
  },
  {
    id: "2",
    name: "Arjun Patel",
    age: 17,
    gender: "Male",
    lastSeen: "2023-06-20",
    description: "Last seen at Delhi Public School after cricket practice.",
    image: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=400",
    reportedBy: "Meera Patel",
    contactInfo: "+91 87654 32109",
    locations: [
      { lat: 28.5425, lng: 77.1953, address: "Delhi Public School, R.K. Puram", timestamp: "2023-06-20T17:15:00" }
    ],
    status: "investigating",
    dateReported: "2023-06-20",
    height: "5'9\"",
    weight: "65 kg",
    hairColor: "Black",
    eyeColor: "Brown",
    distinguishingFeatures: "Scar on right forearm",
    lastSeenWearing: "School uniform and black backpack"
  },
  {
    id: "3",
    name: "Anjali Verma",
    age: 32,
    gender: "Female",
    lastSeen: "2023-07-05",
    description: "Last seen leaving her workplace in Cyber City, Gurgaon around 6 PM.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400",
    reportedBy: "Vikram Verma",
    contactInfo: "+91 76543 21098",
    locations: [
      { lat: 28.4959, lng: 77.0897, address: "Cyber City, Gurgaon", timestamp: "2023-07-05T18:00:00" }
    ],
    status: "found",
    dateReported: "2023-07-06",
    height: "5'6\"",
    weight: "58 kg",
    hairColor: "Brown",
    eyeColor: "Black"
  }
];

// Load data from localStorage
const loadFromLocalStorage = (): MissingPerson[] => {
  try {
    const storedData = localStorage.getItem('missingPersonsData');
    return storedData ? JSON.parse(storedData) : sampleMissingPersons;
  } catch (error) {
    console.error("Error loading data from localStorage:", error);
    return sampleMissingPersons;
  }
};

// Save data to localStorage
const saveToLocalStorage = (data: MissingPerson[]) => {
  try {
    localStorage.setItem('missingPersonsData', JSON.stringify(data));
  } catch (error) {
    console.error("Error saving data to localStorage:", error);
  }
};

export const MissingPersonProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [missingPersons, setMissingPersons] = useState<MissingPerson[]>(() => loadFromLocalStorage());
  const [loading, setLoading] = useState<boolean>(false);
  const [searchResults, setSearchResults] = useState<MissingPerson[] | null>(null);

  // Save to localStorage whenever data changes
  useEffect(() => {
    saveToLocalStorage(missingPersons);
  }, [missingPersons]);

  const addMissingPerson = (person: MissingPerson) => {
    const newPersonWithId = { ...person, id: crypto.randomUUID() };
    setMissingPersons(prev => [...prev, newPersonWithId]);
  };

  const updateMissingPerson = (id: string, updatedPerson: Partial<MissingPerson>) => {
    setMissingPersons(
      missingPersons.map(person =>
        person.id === id ? { ...person, ...updatedPerson } : person
      )
    );
  };

  const deleteMissingPerson = (id: string) => {
    setMissingPersons(missingPersons.filter(person => person.id !== id));
  };

  const getMissingPerson = (id: string) => {
    return missingPersons.find(person => person.id === id);
  };

  const searchMissingPersons = (query: string) => {
    setLoading(true);
    
    try {
      const lowerCaseQuery = query.toLowerCase();
      const results = missingPersons.filter(
        person =>
          person.name.toLowerCase().includes(lowerCaseQuery) ||
          person.description.toLowerCase().includes(lowerCaseQuery) ||
          (person.lastSeenWearing && person.lastSeenWearing.toLowerCase().includes(lowerCaseQuery))
      );
      
      setSearchResults(results);
      return results;
    } finally {
      setLoading(false);
    }
  };

  const clearSearch = () => {
    setSearchResults(null);
  };

  return (
    <MissingPersonContext.Provider
      value={{
        missingPersons,
        addMissingPerson,
        updateMissingPerson,
        deleteMissingPerson,
        getMissingPerson,
        searchMissingPersons,
        loading,
        clearSearch,
        searchResults,
        setSearchResults
      }}
    >
      {children}
    </MissingPersonContext.Provider>
  );
};

export const useMissingPersons = () => {
  const context = useContext(MissingPersonContext);
  if (context === undefined) {
    throw new Error('useMissingPersons must be used within a MissingPersonProvider');
  }
  return context;
};
